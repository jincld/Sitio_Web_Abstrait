const formulario=document.getElementById('Contactanos');
const EnviarBtn=document.getElementById('enviarBtn');

formulario.addEventListener('submit',function(event){
    event.preventDefault();

    const nombreInput = document.getElementById('nombre');
    const nombreValor=nombreInput.value;
    const correo = document.getElementById("correo");
    const correoValor=correo.value;
    const mensaje = document.getElementById("mensaje");
    const mensajeValor=mensaje.value;
    
    if (document.getElementById("nombre").value=="") {
      alert("Debes rellenar el nombre"); 
      return false;
    }
    if (document.getElementById("correo").value=="") {
      alert("Debes poner un correo"); 
      return false;
    }
    if (document.getElementById("mensaje").value=="") {
      alert("Debes poner un mensaje");
      return false;
    }

    alert(`Gracias por tus comentarios ${nombreValor} , tu mensaje ha sido enviado correctamente.`
    );
    formulario.submit();
})


